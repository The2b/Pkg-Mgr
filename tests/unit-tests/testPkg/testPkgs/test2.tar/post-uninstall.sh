#!/bin/bash
touch /tmp/test2-post-uninstall
