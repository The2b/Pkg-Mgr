#!/bin/bash
mkdir /tmp/test2
touch /tmp/test2/pre-install
